// Created by Fynn Godau 2019, licensed GNU GPL version 3 or later

package org.schabi.newpipe.extractor.services.bandcamp.linkHandler;

import static org.schabi.newpipe.extractor.services.bandcamp.extractors.BandcampExtractorHelper.BASE_URL;

import org.schabi.newpipe.extractor.exceptions.ParsingException;
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandlerFactory;
import org.schabi.newpipe.extractor.search.filter.FilterItem;
import org.schabi.newpipe.extractor.services.bandcamp.search.filter.BandcampFilters;
import org.schabi.newpipe.extractor.utils.Utils;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public final class BandcampSearchQueryHandlerFactory extends SearchQueryHandlerFactory {

    private static final BandcampSearchQueryHandlerFactory INSTANCE
            = new BandcampSearchQueryHandlerFactory();

    private BandcampSearchQueryHandlerFactory() {
        super(new BandcampFilters());
    }

    public static BandcampSearchQueryHandlerFactory getInstance() {
        return INSTANCE;
    }

    @Override
    public String getUrl(final String query,
                         @Nonnull final List<FilterItem> selectedContentFilter,
                         @Nullable final List<FilterItem> selectedSortFilter)
            throws ParsingException, UnsupportedOperationException {

        searchFilters.setSelectedSortFilter(selectedSortFilter);
        searchFilters.setSelectedContentFilter(selectedContentFilter);

        final String filterQuery = searchFilters.evaluateSelectedContentFilters();
        return BASE_URL + "/search?q=" + Utils.encodeUrlUtf8(query) + filterQuery + "&page=1";
    }
}
