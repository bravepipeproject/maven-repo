package org.schabi.newpipe.extractor.services.youtube.extractors;

import static org.schabi.newpipe.extractor.utils.Utils.isNullOrEmpty;

import com.grack.nanojson.JsonArray;
import com.grack.nanojson.JsonObject;

import org.schabi.newpipe.extractor.Image;
import org.schabi.newpipe.extractor.exceptions.ParsingException;
import org.schabi.newpipe.extractor.localization.DateWrapper;
import org.schabi.newpipe.extractor.localization.TimeAgoParser;
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper;
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeChannelLinkHandlerFactory;
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeStreamLinkHandlerFactory;
import org.schabi.newpipe.extractor.stream.StreamInfoItemExtractor;
import org.schabi.newpipe.extractor.stream.StreamType;
import org.schabi.newpipe.extractor.utils.JsonUtils;
import org.schabi.newpipe.extractor.utils.Utils;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Note:
 * This extractor is currently (2025-07) only used to extract related video streams.<br>
 * The following features are currently not implemented:
 * <ul>
 *     <li>Shorts: appear in related videos without a duration badge; getDuration() returns -1</li>
 *     <li>Paid content (Premium, members first or only)</li>
 * </ul>
 */
public class YoutubeStreamInfoItemLockupExtractor implements StreamInfoItemExtractor {

    private static final String NO_VIEWS_LOWERCASE = "no views";
    // This approach is language dependant (en-GB)
    // Leading end space is voluntary included
    private static final String PREMIERES_TEXT = "Premieres ";
    private static final DateTimeFormatter PREMIERES_DATE_FORMATTER =
            DateTimeFormatter.ofPattern("dd/MM/yyyy, HH:mm");

    private final JsonObject lockupViewModel;
    private final TimeAgoParser timeAgoParser;

    private StreamType cachedStreamType;
    private String cachedName;
    private Optional<String> cachedDateText;

    private ChannelImageViewModel cachedChannelImageViewModel;
    private JsonArray cachedMetadataRows;

    /**
     * Creates an extractor of StreamInfoItems from a YouTube page.
     *
     * @param lockupViewModel The JSON page element
     * @param timeAgoParser A parser of the textual dates or {@code null}.
     */
    public YoutubeStreamInfoItemLockupExtractor(final JsonObject lockupViewModel,
                                                @Nullable final TimeAgoParser timeAgoParser) {
        this.lockupViewModel = lockupViewModel;
        this.timeAgoParser = timeAgoParser;
    }

    @Override
    public StreamType getStreamType() throws ParsingException {
        if (cachedStreamType == null) {
            cachedStreamType = determineStreamType();
        }
        return cachedStreamType;
    }

    private StreamType determineStreamType() throws ParsingException {
        final JsonArray overlays = JsonUtils.getArray(lockupViewModel,
            "contentImage.thumbnailViewModel.overlays");

        // thumbnailOverlayBadgeViewModel path (legacy/alternate overlay structure)
        if (overlays.streamAsJsonObjects()
            .flatMap(overlay -> overlay
                .getObject("thumbnailOverlayBadgeViewModel")
                .getArray("thumbnailBadges")
                .streamAsJsonObjects())
            .map(thumbnailBadge -> thumbnailBadge.getObject("thumbnailBadgeViewModel"))
            .anyMatch(vm -> {
                if ("THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE".equals(vm.getString("badgeStyle"))) {
                    return true;
                }
                // Fallback: Check if there is a live icon
                return vm.getObject("icon")
                    .getArray("sources")
                    .streamAsJsonObjects()
                    .map(source -> source
                        .getObject("clientResource")
                        .getString("imageName"))
                    .anyMatch("LIVE"::equals);
            })) {
            return StreamType.LIVE_STREAM;
        }

        // thumbnailBottomOverlayViewModel path (used in lockup format for both duration and live)
        if (overlays.streamAsJsonObjects()
            .flatMap(overlay -> overlay
                .getObject("thumbnailBottomOverlayViewModel")
                .getArray("badges")
                .streamAsJsonObjects())
            .map(badge -> badge.getObject("thumbnailBadgeViewModel"))
            .anyMatch(vm -> "THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE".equals(
                vm.getString("badgeStyle")))) {
            return StreamType.LIVE_STREAM;
        }

        return StreamType.VIDEO_STREAM;
    }

    @Override
    public boolean isAd() throws ParsingException {
        final String name = getName();
        return "[Private video]".equals(name)
            || "[Deleted video]".equals(name);
    }

    @Override
    public String getUrl() throws ParsingException {
        try {
            String videoId = lockupViewModel.getString("contentId");
            if (isNullOrEmpty(videoId)) {
                videoId = JsonUtils.getString(lockupViewModel,
                    "rendererContext.commandContext.onTap.innertubeCommand.watchEndpoint.videoId");
            }
            return YoutubeStreamLinkHandlerFactory.getInstance().getUrl(videoId);
        } catch (final Exception e) {
            throw new ParsingException("Could not get url", e);
        }
    }

    @Override
    public String getName() throws ParsingException {
        if (cachedName != null) {
            return cachedName;
        }

        final String name = JsonUtils.getString(lockupViewModel,
            "metadata.lockupMetadataViewModel.title.content");
        if (!isNullOrEmpty(name)) {
            this.cachedName = name;
            return name;
        }
        throw new ParsingException("Could not get name");
    }

    @Override
    public long getDuration() throws ParsingException {
        // Duration cannot be extracted for live streams, but only for normal videos
        // Exact duration cannot be extracted for premieres, an approximation is only available in
        // accessibility context label
        if (isLive() || isPremiere()) {
            return -1;
        }

        final List<String> potentialDurations = JsonUtils.getArray(lockupViewModel,
                "contentImage.thumbnailViewModel.overlays")
            .streamAsJsonObjects()
            .flatMap(jsonObject -> jsonObject
                .getObject("thumbnailBottomOverlayViewModel")
                .getArray("badges")
                .streamAsJsonObjects())
            .map(jsonObject -> jsonObject
                .getObject("thumbnailBadgeViewModel")
                .getString("text"))
            .collect(Collectors.toList());

        if (potentialDurations.isEmpty()) {
            return -1;
        }

        ParsingException parsingException = null;
        for (final String potentialDuration : potentialDurations) {
            if (potentialDuration == null || !potentialDuration.matches(".*\\d.*")) {
                continue;
            }
            try {
                return YoutubeParsingHelper.parseDurationString(potentialDuration);
            } catch (final ParsingException ex) {
                parsingException = ex;
            }
        }

        if (parsingException == null) {
            return -1; // e.g. only "SHORTS" or "CC" badge was present, no duration available
        }

        throw new ParsingException("Could not get duration", parsingException);
    }

    @Override
    public String getUploaderName() throws ParsingException {
        return metadataPart(0, 0)
            .map(this::getTextContentFromMetadataPart)
            .filter(s -> !isNullOrEmpty(s))
            .orElseThrow(() -> new ParsingException("Could not get uploader name"));
    }

    @Override
    public String getUploaderUrl() throws ParsingException {
        final JsonObject innerTubeCommand = channelImageViewModel()
            .forUploaderUrlExtraction()
            .getObject("rendererContext")
            .getObject("commandContext")
            .getObject("onTap")
            .getObject("innertubeCommand");
        final JsonObject browseEndpoint = innerTubeCommand
            .getObject("browseEndpoint");
        final String channelId = browseEndpoint
            .getString("browseId");

        if (channelId != null && channelId.startsWith("UC")) {
            return YoutubeChannelLinkHandlerFactory.getInstance().getUrl("channel/" + channelId);
        }

        final String canonicalBaseUrl = browseEndpoint.getString("canonicalBaseUrl");
        if (!isNullOrEmpty(canonicalBaseUrl)) {
            return resolveUploaderUrlFromRelativeUrl(canonicalBaseUrl);
        }

        final String webCommandMetadataUrl = innerTubeCommand.getObject("commandMetadata")
            .getObject("webCommandMetadata")
            .getString("url");
        if (!isNullOrEmpty(webCommandMetadataUrl)) {
            return resolveUploaderUrlFromRelativeUrl(webCommandMetadataUrl);
        }

        throw new ParsingException("Could not get uploader url");
    }

    private String resolveUploaderUrlFromRelativeUrl(final String relativeUrl)
        throws ParsingException {
        return YoutubeChannelLinkHandlerFactory.getInstance().getUrl(
            relativeUrl.startsWith("/") ? relativeUrl.substring(1) : relativeUrl);
    }

    @Nonnull
    @Override
    public List<Image> getUploaderAvatars() throws ParsingException {
        return YoutubeParsingHelper.getImagesFromThumbnailsArray(
            JsonUtils.getArray(
                channelImageViewModel().forAvatarExtraction(),
                "avatarViewModel.image.sources"));
    }

    @Override
    public boolean isUploaderVerified() throws ParsingException {
        return metadataPart(0, 0)
            .map(jsonObject -> jsonObject
                .getObject("text")
                .getArray("attachmentRuns"))
            .map(YoutubeParsingHelper::hasArtistOrVerifiedIconBadgeAttachment)
            .orElse(false);
    }

    @Nullable
    @Override
    public String getTextualUploadDate() throws ParsingException {
        // Live streams have no upload date
        if (isLive()) {
            return null;
        }

        // Date string might be null e.g. for live streams
        final Optional<String> dateText = getDateText();

        if (isPremiere()) {
            return getDateFromPremiere(dateText);
        }

        return dateText.orElse(null);
    }

    @Nullable
    private String getDateFromPremiere(final Optional<String> dateText) {
        // This approach is language dependent
        // Remove the premieres text from the upload date metadata part
        return dateText.map(str -> str.replace(PREMIERES_TEXT, ""))
                        .orElse(null);
    }

    @Nullable
    @Override
    public DateWrapper getUploadDate() throws ParsingException {
        if (timeAgoParser == null) {
            return null;
        }

        final String textualUploadDate = getTextualUploadDate();
        // Prevent NPE when e.g. a live stream is shown
        if (textualUploadDate == null) {
            return null;
        }

        if (isPremiere()) {
            final String premiereDate = getDateFromPremiere(getDateText());
            if (premiereDate == null) {
                throw new ParsingException("Could not get upload date from premiere");
            }

            try {
                // As we request a UTC offset of 0 minutes, we get the UTC date
                final var dateTime = LocalDateTime.parse(premiereDate, PREMIERES_DATE_FORMATTER);
                return new DateWrapper(dateTime.atZone(ZoneOffset.UTC).toInstant(), false);
            } catch (final DateTimeParseException e) {
                throw new ParsingException("Could not parse premiere upload date", e);
            }
        }

        return timeAgoParser.parse(textualUploadDate);
    }

    @Override
    public long getViewCount() throws ParsingException {
        if (isPremiere()) {
            // The number of people returned for premieres is the one currently waiting
            return -1;
        }

        // Search the info metadata row for text that looks like a view count.
        // YouTube uses 2 rows [author][views,date] for stream items outside channels
        // and 1 row in channels [views,date], so the views text could be in any part
        // of the info row.
        final int infoRowIndex = getInfoMetadataRowIndex();
        Optional<String> optTextContent = findMetadataPartInRow(infoRowIndex, text -> {
            final String lower = text.toLowerCase();
            return lower.matches(".*\\bviews?\\b.*") || lower.contains("watching")
                    || lower.contains("recommended") || lower.contains(NO_VIEWS_LOWERCASE);
        });

        // Fallback: search all rows. Handles livestreams with only 1 metadata row
        // in search/related/kiosk contexts, where that single row contains views.
        if (optTextContent.isEmpty()) {
            optTextContent = findMetadataPartInAllRows(text -> {
                final String lower = text.toLowerCase();
                return lower.matches(".*\\bviews?\\b.*") || lower.contains("watching")
                        || lower.contains("recommended") || lower.contains(NO_VIEWS_LOWERCASE);
            });
        }

        // Fallback to original position if heuristic didn't match
        if (optTextContent.isEmpty()) {
            optTextContent = metadataPart(infoRowIndex, 0)
                    .map(this::getTextContentFromMetadataPart);
        }

        // We could do this inline if the ParsingException would be a RuntimeException -.-
        if (optTextContent.isPresent()) {
            return getViewCountFromViewCountText(optTextContent.get());
        }
        return !isLive()
            ? -1
            // Live streams don't have the metadata row present if there are 0 viewers
            // https://github.com/TeamNewPipe/NewPipeExtractor/pull/1320#discussion_r2205837528
            : 0;
    }

    private long getViewCountFromViewCountText(@Nonnull final String viewCountText)
            throws NumberFormatException, ParsingException {
        // These approaches are language dependent
        if (viewCountText.toLowerCase().contains(NO_VIEWS_LOWERCASE)) {
            return 0;
        } else if (viewCountText.toLowerCase().contains("recommended")) {
            return -1;
        }

        return Utils.mixedNumberWordToLong(viewCountText);
    }

    @Nonnull
    @Override
    public List<Image> getThumbnails() throws ParsingException {
        return YoutubeParsingHelper.getImagesFromThumbnailsArray(
            JsonUtils.getArray(lockupViewModel,
                "contentImage.thumbnailViewModel.image.sources"));
    }

    private ChannelImageViewModel channelImageViewModel() throws ParsingException {
        if (cachedChannelImageViewModel == null) {
            cachedChannelImageViewModel = determineChannelImageViewModel();
        }

        return cachedChannelImageViewModel;
    }

    private ChannelImageViewModel determineChannelImageViewModel() throws ParsingException {
        final JsonObject image = lockupViewModel
            .getObject("metadata")
            .getObject("lockupMetadataViewModel")
            .getObject("image");

        final JsonObject single = image
            .getObject("decoratedAvatarViewModel", null);
        if (single != null) {
            return new SingleChannelImageViewModel(single);
        }

        final JsonObject multi = image.getObject("avatarStackViewModel", null);
        if (multi != null) {
            return new MultiChannelImageViewModel(multi);
        }

        throw new ParsingException("Failed to determine channel image view model");
    }

    private Optional<JsonObject> metadataPart(final int rowIndex, final int partIndex)
        throws ParsingException {
        if (cachedMetadataRows == null) {
            cachedMetadataRows = JsonUtils.getArray(lockupViewModel,
                "metadata.lockupMetadataViewModel.metadata"
                    + ".contentMetadataViewModel.metadataRows");
        }
        return cachedMetadataRows
            .streamAsJsonObjects()
            .skip(rowIndex)
            .limit(1)
            .flatMap(jsonObject -> jsonObject.getArray("metadataParts")
                .streamAsJsonObjects()
                .skip(partIndex)
                .limit(1))
            .findFirst();
    }

    private String getTextContentFromMetadataPart(final JsonObject metadataPart) {
        return metadataPart.getObject("text").getString("content");
    }

    /**
     * Returns the index of the metadata row containing view count and date info.
     * YouTube uses 2 rows [author][views,date] for stream items outside channels
     * and 1 row in channels [views,date] (as they don't return uploader info).
     */
    protected int getInfoMetadataRowIndex() {
        return 1;
    }

    /**
     * Searches the metadata parts of a specific row for text matching the given predicate.
     * This handles variable part order (e.g. [views, date] vs [date, views]) within a row.
     */
    private Optional<String> findMetadataPartInRow(final int rowIndex,
                                                   @Nonnull final Predicate<String> predicate)
            throws ParsingException {
        if (cachedMetadataRows == null) {
            cachedMetadataRows = JsonUtils.getArray(lockupViewModel,
                "metadata.lockupMetadataViewModel.metadata"
                    + ".contentMetadataViewModel.metadataRows");
        }
        return cachedMetadataRows
            .streamAsJsonObjects()
            .skip(rowIndex)
            .limit(1)
            .flatMap(jsonObject -> jsonObject.getArray("metadataParts")
                .streamAsJsonObjects())
            .map(this::getTextContentFromMetadataPart)
            .filter(predicate)
            .findFirst();
    }

    /**
     * Searches all metadata rows for text matching the given predicate.
     * Used as a fallback when the info row doesn't contain the expected data,
     * e.g. for livestreams with only 1 metadata row in search results.
     */
    private Optional<String> findMetadataPartInAllRows(@Nonnull final Predicate<String> predicate)
            throws ParsingException {
        if (cachedMetadataRows == null) {
            cachedMetadataRows = JsonUtils.getArray(lockupViewModel,
                "metadata.lockupMetadataViewModel.metadata"
                    + ".contentMetadataViewModel.metadataRows");
        }
        return cachedMetadataRows
            .streamAsJsonObjects()
            .flatMap(jsonObject -> jsonObject.getArray("metadataParts")
                .streamAsJsonObjects())
            .map(this::getTextContentFromMetadataPart)
            .filter(predicate)
            .findFirst();
    }

    private boolean isLive() throws ParsingException {
        return getStreamType() != StreamType.VIDEO_STREAM;
    }

    private Optional<String> getDateText() throws ParsingException {
        if (cachedDateText == null) {
            // YouTube uses 2 rows [author][views,date] for stream items outside channels
            // and 1 row in channels [views,date] (as they don't return uploader info in them),
            // so the date text could be in any part of the info row.
            final int infoRowIndex = getInfoMetadataRowIndex();
            cachedDateText = findMetadataPartInRow(infoRowIndex, text ->
                    text.endsWith("ago") || text.contains(PREMIERES_TEXT));

            // Fallback: search all rows. Handles livestreams with only 1 metadata row
            // in search/related/kiosk contexts, where that single row may contain the date.
            if (cachedDateText.isEmpty()) {
                cachedDateText = findMetadataPartInAllRows(text ->
                        text.endsWith("ago") || text.contains(PREMIERES_TEXT));
            }

            // Fallback to original positions if heuristic didn't match
            if (cachedDateText.isEmpty()) {
                cachedDateText = metadataPart(infoRowIndex, 1)
                        .map(this::getTextContentFromMetadataPart);
            }
            if (cachedDateText.isEmpty()) {
                cachedDateText = metadataPart(0, 1)
                        .map(this::getTextContentFromMetadataPart);
            }
        }
        return cachedDateText;
    }

    private boolean isPremiere() throws ParsingException {
        return getDateText().map(dateText -> dateText.contains(PREMIERES_TEXT))
                // If we can't get date text, assume it is not a premiere, it should be a livestream
                .orElse(false);
    }

    abstract static class ChannelImageViewModel {
        protected JsonObject viewModel;

        protected ChannelImageViewModel(final JsonObject viewModel) {
            this.viewModel = viewModel;
        }

        public abstract JsonObject forUploaderUrlExtraction();

        public abstract JsonObject forAvatarExtraction();
    }

    static class SingleChannelImageViewModel extends ChannelImageViewModel {
        SingleChannelImageViewModel(final JsonObject viewModel) {
            super(viewModel);
        }

        @Override
        public JsonObject forUploaderUrlExtraction() {
            return viewModel;
        }

        @Override
        public JsonObject forAvatarExtraction() {
            return viewModel.getObject("avatar");
        }
    }

    static class MultiChannelImageViewModel extends ChannelImageViewModel {
        MultiChannelImageViewModel(final JsonObject viewModel) {
            super(viewModel);
        }

        @Override
        public JsonObject forUploaderUrlExtraction() {
            return viewModel
                .getObject("rendererContext")
                .getObject("commandContext")
                .getObject("onTap")
                .getObject("innertubeCommand")
                .getObject("showDialogCommand")
                .getObject("panelLoadingStrategy")
                .getObject("inlineContent")
                .getObject("dialogViewModel")
                .getObject("customContent")
                .getObject("listViewModel")
                .getArray("listItems")
                .streamAsJsonObjects()
                .map(item -> item.getObject("listItemViewModel"))
                .findFirst()
                .orElse(null);
        }

        @Override
        public JsonObject forAvatarExtraction() {
            return viewModel.getArray("avatars")
                .getObject(0);
        }
    }
}
